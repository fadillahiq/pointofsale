<?php return array (
  'category.create' => 'App\\Http\\Livewire\\Category\\Create',
  'category.index' => 'App\\Http\\Livewire\\Category\\Index',
  'category.update' => 'App\\Http\\Livewire\\Category\\Update',
  'product.create' => 'App\\Http\\Livewire\\Product\\Create',
  'product.index' => 'App\\Http\\Livewire\\Product\\Index',
  'product.update' => 'App\\Http\\Livewire\\Product\\Update',
  'report.index' => 'App\\Http\\Livewire\\Report\\Index',
  'transaction.index' => 'App\\Http\\Livewire\\Transaction\\Index',
  'user.create' => 'App\\Http\\Livewire\\User\\Create',
  'user.index' => 'App\\Http\\Livewire\\User\\Index',
  'user.update' => 'App\\Http\\Livewire\\User\\Update',
);