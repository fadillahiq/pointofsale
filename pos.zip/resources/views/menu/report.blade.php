@extends('layouts.app')

@section('title', 'Report - Point Of Sale')
@section('content')
        <livewire:report.index />
@endsection
