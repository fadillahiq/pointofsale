@extends('layouts.app')

@section('title', 'User - Point Of Sale')
@section('content')
    <livewire:user.index />
@endsection
