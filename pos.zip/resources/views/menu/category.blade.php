@extends('layouts.app')

@section('title', 'Category - Point Of Sale')
@section('content')
    <livewire:category.index />
@endsection
