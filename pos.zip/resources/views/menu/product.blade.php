@extends('layouts.app')

@section('title', 'Product - Point Of Sale')
@section('content')
    <livewire:product.index />
@endsection
