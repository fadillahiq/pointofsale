$(document).ready(function() {
    
    "use strict";
    
    $('#tree1').jstree();
    $('#tree2').jstree();
});