<?php $__env->startSection('title', 'Product - Point Of Sale'); ?>
<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('product.index', [])->html();
} elseif ($_instance->childHasBeenRendered('KyKoLqF')) {
    $componentId = $_instance->getRenderedChildComponentId('KyKoLqF');
    $componentTag = $_instance->getRenderedChildComponentTagName('KyKoLqF');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('KyKoLqF');
} else {
    $response = \Livewire\Livewire::mount('product.index', []);
    $html = $response->html();
    $_instance->logRenderedChild('KyKoLqF', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\final-test-eduwork\resources\views/menu/product.blade.php ENDPATH**/ ?>