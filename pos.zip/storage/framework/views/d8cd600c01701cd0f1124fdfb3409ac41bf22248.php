<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from phantom-themes.com/connect/theme/templates/admin1/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 05 Aug 2021 13:58:46 GMT -->
    <head>
        <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldPushContent('styles'); ?>
    </head>

    <body>
        <div class='loader'>
           <?php echo $__env->make('partials.loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="connect-container align-content-stretch d-flex flex-wrap">
            <div class="page-sidebar">
                <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="page-container">
                <div class="page-header">
                    <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="page-content">
                    <div class="main-wrapper">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div>

                <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

        <!-- Javascripts -->
        <?php echo $__env->make('includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldPushContent('scripts'); ?>
    </body>

<!-- Mirrored from phantom-themes.com/connect/theme/templates/admin1/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 05 Aug 2021 13:59:19 GMT -->
</html>
<?php /**PATH D:\xampp\htdocs\final-test-eduwork\resources\views/layouts/app.blade.php ENDPATH**/ ?>