<div class='spinner-grow text-primary' role='status'>
    <span class='sr-only'>Loading...</span>
</div>
<?php /**PATH D:\xampp\htdocs\final-test-eduwork\resources\views/partials/loader.blade.php ENDPATH**/ ?>