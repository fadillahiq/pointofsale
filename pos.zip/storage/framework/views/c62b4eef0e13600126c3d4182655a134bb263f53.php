<div>
    <?php if($formVisible): ?>
        <?php if($statusUpdate): ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.update', [])->html();
} elseif ($_instance->childHasBeenRendered('hrlG2OF')) {
    $componentId = $_instance->getRenderedChildComponentId('hrlG2OF');
    $componentTag = $_instance->getRenderedChildComponentTagName('hrlG2OF');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('hrlG2OF');
} else {
    $response = \Livewire\Livewire::mount('user.update', []);
    $html = $response->html();
    $_instance->logRenderedChild('hrlG2OF', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php else: ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.create', [])->html();
} elseif ($_instance->childHasBeenRendered('jDXMq4y')) {
    $componentId = $_instance->getRenderedChildComponentId('jDXMq4y');
    $componentTag = $_instance->getRenderedChildComponentTagName('jDXMq4y');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jDXMq4y');
} else {
    $response = \Livewire\Livewire::mount('user.create', []);
    $html = $response->html();
    $_instance->logRenderedChild('jDXMq4y', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php endif; ?>
    <?php endif; ?>
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <div class="card card-transactions">
                <div class="card-body">
                    <div>
                        <?php if(session()->has('message')): ?>
                        <script>
                            Swal.fire(
                             'Success',
                             '<?php echo session('message'); ?>',
                             'success'
                             )
                        </script>
                        <?php endif; ?>
                    </div>
                    <h5 class="card-title">Users<button wire:click="createUser" type="button" class="btn btn-primary btn-sm float-right pb-0"><i class="material-icons">add</i></button></h5>
                    <div class="d-flex justify-content-between mt-5">
                        <select class="form-control sm w-auto" wire:model="paginate">
                            <option value="10">10</option>
                            <option value="25">25</option>
                            <option value="50">50</option>
                            <option value="100">100</option>
                        </select>

                        <input type="text" class="form-control col-lg-4 col-md-3 col-sm-2" wire:model="search" placeholder="Search . . ." />
                    </div>
                    <hr>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">No</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Role</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e(Str::slug($user->getRoleNames())); ?></td>
                                    <td>
                                        <button wire:click="getUser(<?php echo e($user->id); ?>)" class="btn btn-warning btn-sm">Edit</button>
                                        <button wire:click="deleteConfirm(<?php echo e($user->id); ?>)" type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#exampleModal">
                                            Delete
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="12"><p class="text-danger text-center">Data Empty !</p></td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <nav aria-label="Page navigation example">
                            <ul class="pagination pagination-circle pl-2 pb-2">
                                <?php echo e($users->links()); ?>

                            </ul>
                        </nav>
                    </div>
                    <div wire:ignore.self class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Delete User</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <i class="material-icons">close</i>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    Are you sure ?
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="button" wire:click.prevent="deleteUser" class="btn btn-danger close-modal" data-dismiss="modal">Delete</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\final-test-eduwork\resources\views/livewire/user/index.blade.php ENDPATH**/ ?>