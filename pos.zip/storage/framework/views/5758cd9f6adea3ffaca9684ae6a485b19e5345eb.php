<?php $__env->startSection('title', 'Dashboard - Point Of Sale'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-3">
            <div class="card savings-card">
                <div class="card-body">
                    <h5 class="card-title">Total Product<span class="card-title-helper"><i class="material-icons">inventory_2</i></span></h5>
                    <div class="savings-stats">
                        <h5><?php echo e($products); ?></h5>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="card savings-card">
                <div class="card-body">
                    <h5 class="card-title">Total Transaction<span class="card-title-helper"><i class="material-icons">shopping_cart</i></span></h5>
                    <div class="savings-stats">
                        <h5><?php echo e($transactions); ?></h5>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="card savings-card">
                <div class="card-body">
                    <h5 class="card-title">Total Category<span class="card-title-helper"><i class="material-icons">add_shopping_cart</i></span></h5>
                    <div class="savings-stats">
                        <h5><?php echo e($categories); ?></h5>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="card savings-card">
                <div class="card-body">
                    <h5 class="card-title">Total User<span class="card-title-helper"><i class="material-icons">people</i></span></h5>
                    <div class="savings-stats">
                        <h5><?php echo e($users); ?></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="card card-transactions">
                <div class="card-body">
                    <h5 class="card-title">Recent Transactions</h5>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">No</th>
                                    <th scope="col">No Invoice</th>
                                    <th scope="col">Cashier Name</th>
                                    <th scope="col">Products Bought</th>
                                    <th scope="col">Quantity</th>
                                    <th scope="col">Category</th>
                                    <th scope="col">Total</th>
                                    <th scope="col">Pay</th>
                                    <th scope="col">Change</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($data->code); ?></td>
                                    <td><?php echo e($data->cashier_name); ?></td>
                                    <td class="font-weight-bold">
                                        <?php $__currentLoopData = $data->productOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <p><?php echo e($productOrder->product->name); ?></p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td class="font-weight-bold">
                                        <?php $__currentLoopData = $data->productOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <p><?php echo e($productOrder->qty); ?></p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td class="font-weight-bold">
                                        <?php $__currentLoopData = $data->productOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <p><?php echo e($productOrder->product->category->name); ?></p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td><span>Rp. <?php echo e(number_format($data->total)); ?></span></td>
                                    <td><span>Rp. <?php echo e(number_format($data->pay)); ?></span></td>
                                    <td><span>Rp. <?php echo e(number_format($data->change)); ?></span></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="12"><p class="text-danger text-center">Data Empty !</p></td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\final-test-eduwork\resources\views/dashboard.blade.php ENDPATH**/ ?>