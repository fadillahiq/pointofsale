<div class="logo-box"><a href="#" class="logo-text">Connect</a><a href="#" id="sidebar-close"><i class="material-icons">close</i></a> <a href="#" id="sidebar-state"><i class="material-icons">adjust</i><i class="material-icons compact-sidebar-icon">panorama_fish_eye</i></a></div>
                <div class="page-sidebar-inner slimscroll">
                    <ul class="accordion-menu">
                        <li class="sidebar-title">
                            Apps
                        </li>
                        <li class="<?php echo e(request()->is('dashboard') ? 'active-page' : ''); ?>">
                            <a href="<?php echo e(route('dashboard')); ?>" class="active"><i class="material-icons-outlined">dashboard</i>Dashboard</a>
                        </li>
                        <li class="sidebar-title">
                            Master Data
                        </li>
                        <li class="<?php echo e(request()->is('menu/category') ? 'active-page' : ''); ?>">
                            <a href="<?php echo e(route('category')); ?>"><i class="material-icons">bookmark_border</i>Category</a>
                        </li>
                        <li class="<?php echo e(request()->is('menu/product') ? 'active-page' : ''); ?>">
                            <a href="<?php echo e(route('product')); ?>"><i class="material-icons">inventory</i>Product</a>
                        </li>
                        <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                        <li class="<?php echo e(request()->is('menu/user') ? 'active-page' : ''); ?>">
                            <a href="<?php echo e(route('user')); ?>"><i class="material-icons">people</i>User</a>
                        </li>
                        <?php endif; ?>
                        <li class="sidebar-title">
                            Menu
                        </li>
                        <li class="<?php echo e(request()->is('menu/transaction') ? 'active-page' : ''); ?>">
                            <a href="<?php echo e(route('transaction')); ?>"><i class="material-icons">shopping_cart</i>Transaction</a>
                        </li>
                        <li class="<?php echo e(request()->is('menu/report') ? 'active-page' : ''); ?>">
                            <a href="<?php echo e(route('report')); ?>"><i class="material-icons">summarize</i>Report</a>
                        </li>
                    </ul>
                </div>
<?php /**PATH D:\xampp\htdocs\final-test-eduwork\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>