<script src="<?php echo e(asset('assets/plugins/jquery/jquery-3.4.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/bootstrap/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/jquery-slimscroll/jquery.slimscroll.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/jquery-sparkline/jquery.sparkline.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/apexcharts/dist/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/blockui/jquery.blockUI.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/flot/jquery.flot.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/flot/jquery.flot.time.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/flot/jquery.flot.symbol.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/flot/jquery.flot.resize.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/flot/jquery.flot.tooltip.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/connect.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/dashboard.js')); ?>"></script>
<?php echo \Livewire\Livewire::scripts(); ?>

<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php /**PATH D:\xampp\htdocs\final-test-eduwork\resources\views/includes/script.blade.php ENDPATH**/ ?>