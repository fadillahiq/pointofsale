<div>
    <?php if($formVisible): ?>
        <?php if($statusUpdate): ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('category.update', [])->html();
} elseif ($_instance->childHasBeenRendered('vXj43W0')) {
    $componentId = $_instance->getRenderedChildComponentId('vXj43W0');
    $componentTag = $_instance->getRenderedChildComponentTagName('vXj43W0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('vXj43W0');
} else {
    $response = \Livewire\Livewire::mount('category.update', []);
    $html = $response->html();
    $_instance->logRenderedChild('vXj43W0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php else: ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('category.create', [])->html();
} elseif ($_instance->childHasBeenRendered('NWu91Jn')) {
    $componentId = $_instance->getRenderedChildComponentId('NWu91Jn');
    $componentTag = $_instance->getRenderedChildComponentTagName('NWu91Jn');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('NWu91Jn');
} else {
    $response = \Livewire\Livewire::mount('category.create', []);
    $html = $response->html();
    $_instance->logRenderedChild('NWu91Jn', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php endif; ?>
    <?php endif; ?>
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <div class="card card-transactions">
                <div class="card-body">
                    <div>
                        <?php if(session()->has('message')): ?>
                        <script>
                            Swal.fire(
                             'Success',
                             '<?php echo session('message'); ?>',
                             'success'
                             )
                        </script>
                        <?php endif; ?>
                    </div>
                    <h5 class="card-title">Categories<button wire:click="createCategory" type="button" class="btn btn-primary btn-sm float-right pb-0"><i class="material-icons">add</i></button></h5>
                    <div class="d-flex justify-content-between mt-5">
                        <select class="form-control sm w-auto" wire:model="paginate">
                            <option value="10">10</option>
                            <option value="25">25</option>
                            <option value="50">50</option>
                            <option value="100">100</option>
                        </select>

                        <input type="text" class="form-control col-lg-4 col-md-3 col-sm-2" wire:model="search" placeholder="Search . . ." />
                    </div>
                    <hr>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">No</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($category->name); ?></td>
                                    <td>
                                        <button wire:click="getCategory(<?php echo e($category->id); ?>)" class="btn btn-warning btn-sm">Edit</button>
                                        <button wire:click="deleteConfirm(<?php echo e($category->id); ?>)" type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#exampleModal">
                                            Delete
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="12"><p class="text-danger text-center">Data Empty !</p></td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <nav aria-label="Page navigation example">
                            <ul class="pagination pagination-circle pl-2 pb-2">
                                <?php echo e($categories->links()); ?>

                            </ul>
                        </nav>
                    </div>
                    <div wire:ignore.self class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Delete Category</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <i class="material-icons">close</i>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    Are you sure ?
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="button" wire:click.prevent="deleteCategory" class="btn btn-danger close-modal" data-dismiss="modal">Delete</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\final-test-eduwork\resources\views/livewire/category/index.blade.php ENDPATH**/ ?>