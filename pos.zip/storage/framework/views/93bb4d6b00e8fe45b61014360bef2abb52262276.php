<div>
    <style>
        .qty {
            width: 20%;
            display: inline;
        }
        @media  screen and (max-width: 767px) {
            .mobile-space {margin-top:10px;}
            .quantity {margin-top:10px;}
        }
    </style>
        <div class="card-body border-bottom">
            <h5 class="card-title">Transactions</h5>
            <div class="form-group pb-5">
                <form class="row mt-3" wire:submit.prevent="store">
                    <div class="col-lg-3" wire:ignore>
                        <select class="form-control <?php $__errorArgs = ['product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="product_id" required data-live-search="true">
                                <option value="">Choose Product</option>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($product->id); ?>" data-tokens="<?php echo e($product->name); ?>"><?php echo e($product->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger">Product already added !</span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-lg-3 quantity">
                        <div class="form-group">
                            <input type="number" class="form-control <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="qty"required placeholder="Enter quantity" />
                        </div>
                        <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger">Quantity should not exceed stock and minimal 1 !</span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-lg-2 mobile-space">
                        <button type="submit" class="btn btn-success">Submit</button>
                    </div>
                </form>
            </div>

            <?php if(session()->has('message')): ?>
            <script>
                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: '<?php echo session('message'); ?>'
                })
            </script>
            <?php endif; ?>
            
        </div>
        <div class="card-body pb-5 mt-3">
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">Product Name</th>
                            <th scope="col">Qty</th>
                            <th scope="col">Price/Qty</th>
                            <th scope="col" style="width: 200px;">Total</th>
                            <th scope="col" style="width: 10px;"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($transaction->product->name); ?></td>
                                <td>
                                    <div>
                                        <?php if($transaction->qty > 1): ?>
                                            <span class="btn btn-danger btn-sm" wire:click="decrement(<?php echo e($transaction->id); ?>)">-</span>
                                        <?php endif; ?>
                                        <input type="text" class="form-control qty text-center" value="<?php echo e($transaction->qty); ?>" readonly>
                                        <?php if($transaction->product->stock >= 1): ?>
                                            <span class="btn btn-success btn-sm hide" wire:click="increment(<?php echo e($transaction->id); ?>)">+</span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td>Rp. <?php echo e(number_format($transaction->product->price)); ?></td>
                                <td>Rp. <?php echo e(number_format($transaction->product->price * $transaction->qty)); ?></td>
                                <td>
                                    <button wire:click="deleteTransaction(<?php echo e($transaction->id); ?>)" class="btn btn-danger btn-sm"><i class="material-icons">delete</i></button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="12"><p class="text-center text-danger">Data Empty !</p></td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                    <tfoot>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td style="text-align:right;">Total Purchase</td>
                        <td>
                            Rp. <?php echo e(number_format($transactions->sum('total'))); ?>

                        </td>
                        <tr>
                            <td style="border:none;"></td>
                            <td style="border:none;"></td>
                            <td style="border:none;"></td>
                            <td style="text-align:right;">Pay</td>
                            <td style="text-align:right;">
                                <input type="number" wire:model="payInput" class="form-control">
                            </td>
                        </tr>
                        <tr>
                            <td style="border:none;"></td>
                            <td style="border:none;"></td>
                            <td style="border:none;"></td>
                            <td style="text-align:right;">Change</td>
                            <td style="text-align:left;" colspan="10">
                                Rp. <?php echo e(number_format($pay - $transactions->sum('total'))); ?>

                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
            <div>
                <button wire:click="submit" class="btn btn-success btn-sm float-right">Submit</button>
            </div>
        </div>
</div>

<?php $__env->startPush('styles'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\xampp\htdocs\final-test-eduwork\resources\views/livewire/transaction/index.blade.php ENDPATH**/ ?>