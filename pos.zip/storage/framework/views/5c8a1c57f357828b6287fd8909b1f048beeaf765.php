<?php $__env->startSection('title', 'User - Point Of Sale'); ?>
<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.index', [])->html();
} elseif ($_instance->childHasBeenRendered('OHWmFMC')) {
    $componentId = $_instance->getRenderedChildComponentId('OHWmFMC');
    $componentTag = $_instance->getRenderedChildComponentTagName('OHWmFMC');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('OHWmFMC');
} else {
    $response = \Livewire\Livewire::mount('user.index', []);
    $html = $response->html();
    $_instance->logRenderedChild('OHWmFMC', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\final-test-eduwork\resources\views/menu/user.blade.php ENDPATH**/ ?>