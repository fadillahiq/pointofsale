<?php $__env->startSection('title', 'Category - Point Of Sale'); ?>
<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('category.index', [])->html();
} elseif ($_instance->childHasBeenRendered('jqd667Z')) {
    $componentId = $_instance->getRenderedChildComponentId('jqd667Z');
    $componentTag = $_instance->getRenderedChildComponentTagName('jqd667Z');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jqd667Z');
} else {
    $response = \Livewire\Livewire::mount('category.index', []);
    $html = $response->html();
    $_instance->logRenderedChild('jqd667Z', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\final-test-eduwork\resources\views/menu/category.blade.php ENDPATH**/ ?>