<?php $__env->startSection('title', 'Report - Point Of Sale'); ?>
<?php $__env->startSection('content'); ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('report.index', [])->html();
} elseif ($_instance->childHasBeenRendered('DXuhW2j')) {
    $componentId = $_instance->getRenderedChildComponentId('DXuhW2j');
    $componentTag = $_instance->getRenderedChildComponentTagName('DXuhW2j');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('DXuhW2j');
} else {
    $response = \Livewire\Livewire::mount('report.index', []);
    $html = $response->html();
    $_instance->logRenderedChild('DXuhW2j', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\final-test-eduwork\resources\views/menu/report.blade.php ENDPATH**/ ?>