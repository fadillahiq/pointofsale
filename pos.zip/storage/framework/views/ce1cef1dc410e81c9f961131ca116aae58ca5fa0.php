<div>
    <div class="row">
        <div class="col-lg-12 mx-auto">
            <div class="card card-transactions">
                <div class="card-body">
                    <h5 class="card-title">Report<button wire:click="export_mapping" type="button" class="btn btn-success btn-sm float-right pb-0"><i class="material-icons">cloud_download</i></button></h5>
                    <div class="d-flex justify-content-between mt-5">
                        <select class="form-control sm w-auto" wire:model="paginate">
                            <option value="10">10</option>
                            <option value="25">25</option>
                            <option value="50">50</option>
                            <option value="100">100</option>
                        </select>

                        <input type="text" class="form-control col-lg-4 col-md-3 col-sm-2" wire:model="search" placeholder="Search . . ." />
                    </div>
                    <hr>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">No</th>
                                    <th scope="col">No Invoice</th>
                                    <th scope="col">Cashier Name</th>
                                    <th scope="col">Products Bought</th>
                                    <th scope="col">Quantity</th>
                                    <th scope="col">Category</th>
                                    <th scope="col">Total</th>
                                    <th scope="col">Pay</th>
                                    <th scope="col">Change</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($data->code); ?></td>
                                    <td><?php echo e($data->cashier_name); ?></td>
                                    <td class="font-weight-bold">
                                        <?php $__currentLoopData = $data->productOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <p><?php echo e($productOrder->product->name); ?></p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td class="font-weight-bold">
                                        <?php $__currentLoopData = $data->productOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <p><?php echo e($productOrder->qty); ?></p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td class="font-weight-bold">
                                        <?php $__currentLoopData = $data->productOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <p><?php echo e($productOrder->product->category->name); ?></p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td><span>Rp. <?php echo e(number_format($data->total)); ?></span></td>
                                    <td><span>Rp. <?php echo e(number_format($data->pay)); ?></span></td>
                                    <td><span>Rp. <?php echo e(number_format($data->change)); ?></span></td>
                                    <td>
                                        <form method="GET" action="<?php echo e(route('invoice', $data->code)); ?>">
                                            <button type="submit" class="btn btn-primary"><span class="material-icons" style="font-size: 15px;">print</span></button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="12"><p class="text-danger text-center">Data Empty !</p></td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <nav aria-label="Page navigation example">
                            <ul class="pagination pagination-circle pl-2 pb-2">
                                <?php echo e($datas->links()); ?>

                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('styles'); ?>
<script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.8.2/dist/alpine.min.js" defer></script>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\xampp\htdocs\final-test-eduwork\resources\views/livewire/report/index.blade.php ENDPATH**/ ?>